#ifndef UART1FUNCTIONS_H
#define	UART1FUNCTIONS_H

#include "xc.h"

void UART1Setup();
void sendCharacter(char);
#endif	/* UART1FUNCTIONS_H */