/* 
 * File:   timer1Functions.h
 * Author: Ren�
 *
 * Created on 11 November 2018, 15:21
 */

#ifndef TIMER1FUNCTIONS_H
#define	TIMER1FUNCTIONS_H

#include "xc.h"

void timer1Setup();
#endif	/* TIMER1FUNCTIONS_H */

