#include "PWM1Functions.h"

void pwmSetup()
{
    PTCONbits.PTEN = 0; // switch off PWM time base during configuration
    PTCONbits.PTCKPS1 = 1; //choose time base prescaler 8 (1st bit)
    PTCONbits.PTCKPS0 = 1; //choose time base prescaler 8 (2nd bit)
    PTPER = 999; // set the PWM period
    PWMCON1bits.PMOD1 = 1; // set PWM unit 1 into the independent mode
    PWMCON1bits.PEN1L = 1; // enable PWM 1 low-side driver
    PWMCON1bits.PEN1H = 1; // enable PWM 1 high-side driver
    PTCONbits.PTEN = 1; // switch on the PWM generator
}
