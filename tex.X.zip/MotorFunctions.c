#include <p30F4012.h>

#include "MotorFunctions.h"

void motorSetup()
{
    TRISBbits.TRISB2 = 0;
    PORTBbits.RB2 = 1;
}
