/* 
 * File:   Timer1Functions.h
 * Author: Natalia
 *
 * Created on 11 November 2018, 15:21
 */

#ifndef TIMER1FUNCTIONS_H
#define	TIMER1FUNCTIONS_H

#include "xc.h"

void Timer1Setup();
#endif	/* TIMER1FUNCTIONS_H */

