/* 
 * File:   PWM1Functions.h
 * Author: Natalia
 *
 * Created on 18 November 2018, 15:46
 */

#ifndef PWM1FUNCTIONS_H
#define	PWM1FUNCTIONS_H
#include <p30F4012.h>

void pwmSetup();

#endif	/* PWM1FUNCTIONS_H */

