
#ifndef	QEI_FUNCTIONS_H
#define	QEI_FUNCTIONS_H

void setupQEI();

#endif
