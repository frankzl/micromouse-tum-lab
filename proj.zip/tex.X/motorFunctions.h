/* 
 * File:   MotorFunctions.h
 * Author: Natalia
 *
 * Created on 07 December 2018, 14:23
 */

#ifndef MOTORFUNCTIONS_H
#define	MOTORFUNCTIONS_H

void motorSetup();

void setMotorDir( int );

void changeMotorDir();

#endif	/* MOTORFUNCTIONS_H */

